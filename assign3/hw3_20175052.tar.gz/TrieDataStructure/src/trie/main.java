package trie;

import java.util.ArrayList;

public class main {
    public static void main(String[] args) {
        /** OPTIONAL **/
        // Test freely whether your implementation is correct.

        ArrayList<ItemSet> matchedItemSet = new ArrayList<>();

        Trie trie = new Trie(2);

        trie.printTrie(trie.getRootNode());
        ArrayList<Integer> transaction = new ArrayList<>();

        transaction.add(1);
        transaction.add(2);
        transaction.add(3);
        transaction.add(4);
        trie.findItemSets(matchedItemSet,transaction);

        System.out.println(matchedItemSet);
    }


}
