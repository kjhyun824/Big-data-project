package trie;

import java.util.ArrayList;

public class main {
    public static void main(String[] args) {
        /** OPTIONAL **/
        // Test freely whether your implementation is correct.

        ArrayList<ItemSet> matchedItemSet = new ArrayList<>();

        System.out.println(matchedItemSet);
    }


}
