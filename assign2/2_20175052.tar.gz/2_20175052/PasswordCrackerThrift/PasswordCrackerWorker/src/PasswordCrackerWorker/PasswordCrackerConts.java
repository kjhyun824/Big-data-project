package PasswordCrackerWorker;

public class PasswordCrackerConts {
    public static final String PASSWORD_CHARS = "0123456789abcdefghijklmnopqrstuvwxyz";
    public static final int PASSWORD_LEN = 6;
    public static final long INTERVAL = 1l;
    public static final long INITIAL_DELAY = 0l;
}
